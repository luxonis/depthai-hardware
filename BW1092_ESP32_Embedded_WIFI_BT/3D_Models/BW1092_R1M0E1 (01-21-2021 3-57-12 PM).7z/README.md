### Information on the STEP Files:

* Files with "AllComponents" in the filename contain 3D information about all components on the BOM, even components which are not stuffed for production including the module and heatsink. 
* Files with "Production" in the filename are those which contain only 3D information about the components which are stuffed for production of the PCBAs. 
